package worker;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.exceptions.JedisConnectionException;
import java.sql.*;
import org.json.JSONObject;

class Worker {
  public static void main(String[] args) {
    try {
      Jedis redis = connectToRedis(System.getenv("REDIS_HOST"));
      Connection dbConn = connectToDB();

      System.err.println("Watching vote queue");

      while (true) {
        String voteJSON = redis.blpop(0, "votes").get(1);
        JSONObject voteData = new JSONObject(voteJSON);
        String voterID = voteData.getString("voter_id");
        String vote = voteData.getString("vote");

        System.err.printf("Processing vote for '%s' by '%s'\n", vote, voterID);
        updateVote(dbConn, voterID, vote);
      }
    } catch (SQLException e) {
      e.printStackTrace();
      System.exit(1);
    }
  }

  static void updateVote(Connection dbConn, String voterID, String vote) throws SQLException {
    PreparedStatement upsert = dbConn.prepareStatement(
        "INSERT INTO votes (id, vote) VALUES (?, ?) ON CONFLICT (id) DO UPDATE SET vote = EXCLUDED.vote");
    upsert.setString(1, voterID);
    upsert.setString(2, vote);
    upsert.executeUpdate();
  }

  static Jedis connectToRedis(String host) {
    Jedis conn = new Jedis(host, 6379);
    String password = System.getenv("REDIS_PASSWORD");

    while (true) {
      try {
        if (password != null && !password.isEmpty()) {
          conn.auth(password);
        }
        conn.keys("*");
        break;
      } catch (JedisConnectionException e) {
        System.err.printf("Waiting for redis: %s%n", e.getMessage());
        sleep(1000);
      }
    }

    System.err.println("Connected to redis");
    return conn;
  }

  static Connection connectToDB() throws SQLException {
    Connection conn = null;

    try {

      Class.forName("org.postgresql.Driver");
      String url = "jdbc:postgresql://" + System.getenv("POSTGRES_HOST") + ':' + System.getenv("POSTGRES_PORT")
          + "/" + System.getenv("POSTGRES_DB");

      while (conn == null) {
        try {
          conn = DriverManager.getConnection(url, System.getenv("POSTGRES_USER"),
              System.getenv("POSTGRES_PASSWORD"));
        } catch (SQLException e) {
          System.err.printf("Waiting for db: %s%n",
              e.getMessage());
          sleep(1000);
        }
      }

    } catch (ClassNotFoundException e) {
      e.printStackTrace();
      System.exit(1);
    }

    System.err.println("Connected to db");
    return conn;
  }

  static void sleep(long duration) {
    try {
      Thread.sleep(duration);
    } catch (InterruptedException e) {
      System.exit(1);
    }
  }
}
