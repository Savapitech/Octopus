const express = require('express');
const { Pool } = require('pg');

const pool = new Pool({
  host: process.env.POSTGRES_HOST,
  port: parseInt(process.env.POSTGRES_PORT || '5432'),
  database: process.env.POSTGRES_DB || 'paul',
  user: process.env.POSTGRES_USER || 'paul',
  password: process.env.POSTGRES_PASSWORD,
});

const app = express();

const options = {
  a: process.env.OPTION_A || 'Ansible',
  b: process.env.OPTION_B || 'Chef',
  c: process.env.OPTION_C || 'Puppet',
  d: process.env.OPTION_D || 'SaltStack',
};

app.get('/', async (req, res) => {
  try {
    const { rows } = await pool.query('SELECT vote, COUNT(id) AS count FROM votes GROUP BY vote');
    const votes = { a: 0, b: 0, c: 0, d: 0 };
    rows.forEach(row => { votes[row.vote] = parseInt(row.count); });
    const total = Object.values(votes).reduce((a, b) => a + b, 0) || 1;

    res.send(`<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Voting Results</title>
  <meta http-equiv="refresh" content="5">
  <style>
    body { font-family: Arial, sans-serif; background: #f4f4f4; text-align: center; padding: 40px; }
    h1 { color: #333; }
    .results { display: flex; justify-content: center; gap: 20px; flex-wrap: wrap; margin-top: 30px; }
    .card { background: white; border-radius: 8px; padding: 30px 40px; box-shadow: 0 2px 8px rgba(0,0,0,.1); min-width: 180px; }
    .card h2 { margin: 0 0 10px; font-size: 1.2em; color: #555; }
    .count { font-size: 3em; font-weight: bold; color: #2196F3; }
    .percent { color: #888; font-size: .9em; margin-top: 5px; }
  </style>
</head>
<body>
  <h1>Voting Results</h1>
  <p>What's your favorite DevOps tool?</p>
  <div class="results">
    ${Object.entries(options).map(([k, label]) => `
    <div class="card">
      <h2>${label}</h2>
      <div class="count">${votes[k]}</div>
      <div class="percent">${(votes[k] / total * 100).toFixed(1)}%</div>
    </div>`).join('')}
  </div>
</body>
</html>`);
  } catch (err) {
    console.error(err);
    res.status(500).send('Database error: ' + err.message);
  }
});

const PORT = process.env.PORT || 80;
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Result server listening on port ${PORT}`);
});
